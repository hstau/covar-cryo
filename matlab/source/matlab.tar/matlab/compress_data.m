function da = compress_data(data,ind2, i)
%addpath /home/liaoh/lib/matlab

% decompose 
find2 = ind2{1};
cind2 = ind2{2};
find2 = find2(:,i);
cind2 = cind2(:,i);
%
I = size(find(cind2),1) + size(find(find2),1);
da = zeros(I,1);
%
datas = scale2(data);
data = data(:);
datas = datas(:);
% fine grid
I = find(find2);
find2 = find2(I);
da(find2) = data(I);
% coarse grid
I = find(cind2);
cind2 = cind2(I);
da(cind2) = datas(I);
