% pretty idea but consume too much memo
function cov = compress_data(cov,ind2, i)
addpath /guam.raid.home/liaoh/lib/matlab
%
ss = size(cov,1);
NX = sqrt(ss);
NX2 = NX/2;
% decompose 
find2 = ind2{1};
cind2 = ind2{2};
find2 = find2(:,i);
cind2 = cind2(:,i);
%
CC = find(cind2);     % coordinates of good pixels
FF = find(find2);      
%
I = size(CC,1) + size(FF,1);
% create adjacency matrix image to image
Ad = zeros(ss,I);
%   for fine part is easy: orig image -> find2 
Ad(FF,find2(FF)) = 1;
%   for coarse part, need scaling: orig image -> scale2 -> cind2
[a b] = decomp2(CC-1,[NX2 NX2]);
v = [2*a 2*b; 2*a+1 2*b; 2*a 2*b+1; 2*a+1 2*b+1]; % all 4 possible
a = v(:,1); 
b = v(:,2);
F = sum([a b].*repmat([1 NX],size(a,1),1),2) + 1;
mapc = repmat(cind2(CC),4,1);
Ad(F, mapc) = 1;
%   sparcity
Ad = sparse(Ad);
Ad = Ad./repmat(sum(Ad),size(Ad,1),1);  % normalize
% adjacency matrix covariance to covariance 
tic
Ad = kron(Ad,Ad);
toc
% finally: multiply adj matrix by covariance to get new covariance
cov = cov(:)'*Ad;
cov = cov(:);
