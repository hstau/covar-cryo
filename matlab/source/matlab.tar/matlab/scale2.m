function prjs = scale(prj)
%addpath /home/liaoh/lib/matlab

prjs = zeros(size(prj)/2);
for i = 1:2
    for j=1:2
        prjs = prjs + prj(i:2:end,j:2:end,:);
    end
end
prjs = prjs/4;