

function mask = neighbor1(cov_2d)
% sizes
M = size(cov_2d,1);
NX = sqrt(M);
mask = zeros(M,M);
for i=1:NX
    for j=i:NX
        ind = (i-1)*NX + j;
        % verical
        for k = -1:2:1
            x = min(max(i+k,1),NX);
            y = j;
            ind1 = (x-1)*NX + y;
            mask(ind,ind1) = 1;
            mask(ind1,ind) = 1;
        end
        % horizontal
        for k = -1:2:1
            x = i;
            y = min(max(j+k,1),NX);
            ind1 = (x-1)*NX + y;
            mask(ind,ind1) = 1;
            mask(ind1,ind) = 1;
        end
    end
end

function mask = neighbor2(cov_2d)
% sizes
M = size(cov_2d,1);
NX = sqrt(M);
mask = zeros(M,M);
for i=1:NX
    for j=i:NX
        ind = (i-1)*NX + j;
        % diag
        for k = -1:2:1
            for l = -1:2:1
            x = min(max(i+k,1),NX);
            y = min(max(j+l,1),NX);
            ind1 = (x-1)*NX + y;
            mask(ind,ind1) = 1;
            mask(ind1,ind) = 1;
            end
        end
    end
end

function [m0,m1,m2] = neigh(cov_noise)
% size of cov_noise
M = size(cov_noise,1);
% get the neighbor masks
n0 = eye(M);
n1 = neighbor1(cov_noise);
n2 = neighbor2(cov_noise);
% masked values
l0 = cov_noise.*n0; 
l1 = cov_noise.*n1;
l2 = cov_noise.*n2;
% averages
m0 = mean(l0(find(l0)));
m1 = mean(l1(find(l1)));
m2 = mean(l2(find(l2)));
% weighted mask
%l0 = m0*n0; 
%l1 = m1*n1;
%l2 = m2*n2;

