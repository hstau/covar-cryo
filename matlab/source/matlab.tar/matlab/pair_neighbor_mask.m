function mask = neighbor(cov_2d, i, ind2)  % THIS CODE IS NOT RIGHT
%indeces
cind2 = ind2{2};
cind2 = cind2(:,i);
find2 = ind2{1};
find2 = find2(:,i);
% reduced size
M = size(cov_2d,1);
for  t = 2:14
    mask{t} = zeros(M);
end
% normal size
NX = sqrt(size(find2,1));
NX2 = NX/2;
for i=1:NX
    for j=1:NX
        x = i-1;
        y = j-1;
        % initialize
        f1 = 0;
        % try fine grid
        ind = y*NX + x + 1;
        %if x == 20 & y == 6
        %    ind
        % end
        nind = find2(ind);
        if(nind > 0) % fine grid
            f1 = 2; 
        else         % try coarse grid
            x = floor(x/2);
            y = floor(y/2);
            ind = y*NX2 + x + 1;
            nind = cind2(ind);
            if (nind > 0)  % coarse grid   
                f1 = 1;
            end
        end
        if (f1 > 0)    % if in the grid
            for k = -1:1    % check the eight neighbors
                for l = -1:1
                    %if(mod(k+l,2) == 1) % exclude diagonal 
                   % initialize
                   f2 = 0;
                   % neighbor coord
                   a = min(max(i+k,1),NX) - 1;
                   b = min(max(j+l,1),NX) - 1;
                   ind1 = b*NX + a + 1;
                   nind1 = find2(ind1);
                   if(nind1 > 0)  % fine grid
                       f2 = 2; 
                   else           % try coarse
                       a1 = floor(a/2);
                       b1 = floor(b/2);
                       ind1 = b1*NX2 + a1 + 1;
                       nind1 = cind2(ind1);
                       if (nind1 > 0 & nind1 == nind) % if coarse but the same (did not jump far enough) 
                           k = 2*k;                   % jump further   
                           j = 2*j;
                           a = min(max(i+k,1),NX) - 1;
                           b = min(max(j+l,1),NX) - 1;
                           a1 = floor(a/2);
                           b1 = floor(b/2);
                           ind1 = b1*NX2 + a1 + 1;
                           nind1 = cind2(ind1);
                           if (nind1 > 0)              % found another coarse neighbor
                               f2 = 1; %  coarse scale
                           end
                       end
                   end
                   if(f2 > 0 & nind1 ~= nind)
                       t = f1+f2;
                       mask{t}(nind,nind1) = 1;
                       mask{t}(nind1,nind) = 1;
                   end
                    %end
                end
            end   
        end
        if(f1 > 0)
              for k = -2:2    % check more neighbors (order 2) THIS DOES NOT WORK WITH BOTH BEING COARSE !!!
                for l = -2:2
                   if((abs(k) > 1 | abs(l) > 1) & (abs(k)+abs(l) < 4)) % exclude 4 corners 
                      % initialize
                      f2 = 0;
                      % neighbor coord
                      a = min(max(i+k,1),NX) - 1;
                      b = min(max(j+l,1),NX) - 1;
                      ind1 = b*NX + a + 1;
                      nind1 = find2(ind1);
                      if(nind1 > 0)  % fine grid
                          f2 = 2; 
                      else           % try coarse
                          a1 = floor(a/2);
                          b1 = floor(b/2);
                          ind1 = b1*NX2 + a1 + 1;
                          nind1 = cind2(ind1);
                          if (nind1 > 0 & nind1 == nind) % if coarse but the same (did not jump far enough) 
                              k = 2*k;                   % jump further   
                              j = 2*j;
                              a = min(max(i+k,1),NX) - 1;
                              b = min(max(j+l,1),NX) - 1;
                              a1 = floor(a/2);
                              b1 = floor(b/2);
                             ind1 = b1*NX2 + a1 + 1;
                             nind1 = cind2(ind1);
                             if (nind1 > 0)              % found another coarse neighbor
                                 f2 = 1; %  coarse scale
                             end
                          end
                      end
                      if(f2 > 0 & nind1 ~= nind)
                          t = f1+f2+10;
                          mask{t}(nind,nind1) = 1;
                          mask{t}(nind1,nind) = 1;
                      end
                   end
                end
              end
        end
    end   
end

%for  t = 2:4 % necessary?
%    mask{t} = mask{t} - diag(diag(mask{t}));
%end
