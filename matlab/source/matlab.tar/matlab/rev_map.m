% reverse mapping
function rind =rev_map(mapi)
%addpath /home/liaoh/lib/matlab

mi = min(mapi);
ma = max(mapi);
rind = zeros(ma - mi + 1,1);  % mi is negative
rind(mapi - mi+1) = [1: size(mapi,1)];