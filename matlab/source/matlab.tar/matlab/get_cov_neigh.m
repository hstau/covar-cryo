function cov = normalize(cov_2d, cov_sh, i, ind2, maski, masko)
% get the size
cind2 = ind2{2};
cind2 = cind2(:,i);
%
I = size(find(cind2),1);
M = size(cov_2d,1);
% both scales
[d0,d1,l1,l2,l3,ll1,ll2,ll3] = pair_neigh_value(cov_sh, i, ind2, maski); % for fine and hybrid scales
[e0,e1,s1,s2,s3,ss1,ss2,ss3] = pair_neigh_value(cov_2d, i, ind2, masko);    % for coarse scale
% the diag part
e0,d1
t0 = diag([e0*ones(I,1); d1*ones(M-I,1)]);
% the intra-coarse part
t1 = s1;
if(sum(s1) > 0) 
    m1 = mean(s1(find(s1)))
end
%mean(t1(:))
% the hybrid part
t2 = l2;
if(sum(l2) > 0) 
    m2 = mean(l2(find(l2)))
end
% the intra-fine part
t3 = l3;
if(sum(l3) > 0) 
    m3 = mean(l3(find(l3)))
end
% the intra-coarse part
t4 = ss1;
if(sum(ss1) > 0) 
    mm1 = mean(ss1(find(ss1)));
end
%mean(t4(:))
% the hybrid part
t5 = ll2;
if(sum(ll2) > 0) 
    mm2 = mean(ll2(find(ll2)));
end
% the intra-fine part
t6 = ll3;
if(sum(ll3) > 0) 
    mm3 = mean(ll3(find(ll3)))
end
%put together
cov = t0 + t1 + t2 + t3;% + t4 + t5 +t6;

% test
k1 = sum(t1);
k1 = k1 > 0;
k1= expand_data(k1,ind2,i,[32 32]);
save k1
% test
k0 = diag(t0);
k0= expand_data(k0,ind2,i,[32 32]);
save k0
