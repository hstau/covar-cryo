function var = get_diag(cov_2d,ind2,j)
%addpath /home/liaoh/lib/matlab

% sizes
M = size(cov_2d,1);
cind2 = ind2{2};   % recall szie(cind2,2)=195
S = size(cind2,1);
NX2 = sqrt(S);
NX = 2*NX2;
p_dim(1) = NX;
p_dim(2) = NX;
%
cov_2d = cov_2d(:);
%neg = sum(cov_2d<0)
all = ([1:M]-1)*M + [1:M];
var = cov_2d(all);
var = expand_data(var,ind2,j,p_dim);