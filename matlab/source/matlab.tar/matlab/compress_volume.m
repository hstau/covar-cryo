function array = compress_volume(vol,ind3,v_dim)    
%addpath /home/liaoh/lib/matlab

% allocating mem
find3 = ind3{1};
cind3 = ind3{2};
I = size(find(cind3),1) + size(find(find3),1); 
array = zeros(I,1);
% scaling 
vols = scale3(vol);
vol = vol(:);
vols = vols(:);
% fine grid
I = find(find3);
find3 = find3(I);
array(find3) = vol(I);
% coarse grid
I = find(cind3);
cind3 = cind3(I);
array(cind3) = vols(I);

  
