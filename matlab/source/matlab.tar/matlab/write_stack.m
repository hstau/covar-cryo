function write_stack(head,j,data)
%addpath /home/liaoh/lib/matlab

string = head;
fid=fopen(string,'w');
fprintf(fid, '%f \n', data);
fclose(fid);

