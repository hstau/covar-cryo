function write2(out,toti,i)
%addpath /home/liaoh/lib/matlab

save(out,'-v7.3','toti');
%out=strcat('big_tot_matlab/tot_',num2str(i,'%05d'),'.txt');
%dlmwrite(out,toti,'precision',32,'delimiter',' ')
