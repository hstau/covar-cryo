function prj = get_cov(prj_head,sel, i, ext)
% read an image to get the dimensions
u = sel(1);
string=strcat(prj_head,num2str(u,'%06d'),ext);
part = readSPIDERfile(string);
part = part(:);
% vector for the differences for each pixel
prj = zeros(size(sel,1),size(part,1));
% compute the average
for k = 1:size(sel,1)
    u = sel(k);
    % read a particle
    string=strcat(prj_head,num2str(u,'%06d'),ext);
    part = readSPIDERfile(string); 
    part = part(:);   
    prj(k,:) = part';
end

