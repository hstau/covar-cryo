function get_diag_full(cov,string,permu)
addpath /guam.raid.cluster.software/relion_more/matlab_lib/
ss = sqrt(size(cov,1))
var = reshape(cov,ss,ss);
var = diag(var);
ss = round((size(var,1))^(1/3))
var= reshape(var,ss,ss,ss);
if permu == 1
    var = permute(var,[2 1 3]);
end
writeSPIDERfile(string,var);