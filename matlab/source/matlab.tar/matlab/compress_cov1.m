function new_cov = compress_data(cov,ind2, i)
addpath /guam.raid.home/liaoh/lib/matlab
%
ss = size(cov,1);
if(ss ~= size(cov,2))
    ss = sqrt(ss);
end
NX = sqrt(ss);
NX2 = NX/2;
% decompose 
find2 = ind2{1};
cind2 = ind2{2};
find2 = find2(:,i);
cind2 = cind2(:,i);
%
II = [find(cind2);find(find2)]; % coordinates of good pixels
%
IC = size(find(cind2),1);
I =  size(II,1);
%
new_cov = zeros(I);
% resize cov
cov = cov(:);
new_cov = new_cov(:);
%  
for i1 = 1:I
    ind1 = II(i1);
    F1 = obtain_ab(i1,IC,ind1,NX2,NX);
    for i2 = i1:I
        ind2 = II(i2);
        ind = (i1-1)*I + i2;
        F2 = obtain_ab(i2,IC,ind2,NX2,NX);
        % combine
        F1a = repmat(F1,1,size(F2,1));  
        F2a = repmat(F2,1,size(F1,1));
        new_ind = (F1a-1)*ss + F2a';   
        new_ind = new_ind(:);
        % compressed cov value
        new_cov(ind) = mean(cov(new_ind)); 
    end
end

        
function F = obtain_ab(i,IC,ind,NX2, NX)
if i <= IC %  for coarse part, need scaling: orig image -> scale2 -> cind2
    [a b] = decomp2(ind-1,[NX2 NX2]);
    v = [2*a 2*b; 2*a+1 2*b; 2*a 2*b+1; 2*a+1 2*b+1]; % all 4 possible
    a = v(:,1); b = v(:,2);
    F = sum([a b].*repmat([1 NX],size(a,1),1),2) + 1;
else
    F = ind;
end

