function cov_2d = get_cov(prj_head_s,maski, sel, ind2, i, ext)
% read an image to get the dimensions
u = sel(1);
string=strcat(prj_head_s,num2str(u,'%06d'),ext);
part = readSPIDERfile(string);
ss = size(part,1);
maski = reshape(maski,ss,ss);
% comrpress this image
da = compress_data(part,ind2, i);
% vector for the differences for each pixel
I = size(da(:),1);
par = zeros(I,size(sel,1));
% K bootstrap samples from one sample which is sel
K = 10;
stats = bootstrp(K,@(x) x, sel); % stats is K x size(sel,1)
save stats
% compute the average
cov_2d = zeros(I);
for j = 1:K % for each bootstrap sample
    samp = stats(j,:);
    samp = samp';
    cov_2d = cov_2d + comp_cov_loop(stats,prj_head_s, maski, samp, ind2, i,ext,I);
end
cov_2d = cov_2d/K;


function cov = comp_cov_loop(stats,prj_head_s, maski, sel, ind2, i, ext,I)
par = zeros(I,size(sel,1));
for k = 1:size(sel,1)
        u = sel(k);
        % read a particle
        string=strcat(prj_head_s,num2str(u,'%06d'),ext);
        part_s = readSPIDERfile(string);
        part = part_s.*maski;
        max_sh = floor(0.4*size(part,1));
        sh_x = randi(max_sh);
        sh_y = randi(max_sh);
        part = FourierShift2D(part, [sh_x sh_y]);
        % compress data
        da = compress_data(part,ind2, i);
        % distance from the ave
        par(:,k) = da;
end
ave = mean(par,2);
% compute the differences
par = par-repmat(ave,[1 size(sel,1)]);

% compute the cov matrix
cov= par*par'/(size(sel,1)-1);




