function get_diag_full(cov,string)
addpath /guam.raid.cluster.software/relion_more/matlab_lib/
ss = sqrt(size(cov,1))
var = reshape(cov,ss,ss);
var = diag(var);
ss = sqrt(size(var,1))
var= reshape(var,ss,ss);
writeSPIDERfile(string,var);