function par = get_cov(S,sel_head,prj_head,ext)
mmax = 500;
% read an image to get the dimensions
j = S(1);
string=strcat(sel_head,num2str(j,'%05d'),ext);
sel = readSPIDERdoc(string);
u = sel(1);
string=strcat(prj_head,num2str(u,'%06d'),ext);
part = readSPIDERfile(string);  
% vector
par = zeros(size(part(:),1),mmax);
tot = 0;
for i = 1:size(S,1)
    j = S(i);
    % list of particles for an angle
    string=strcat(sel_head,num2str(j,'%05d'),ext);
    sel = readSPIDERdoc(string);
    for k = 1:size(sel,1)
        u = sel(k);
        tot = tot + 1;
        if tot  < mmax
            % read a particle
            string=strcat(prj_head,num2str(u,'%06d'),ext);
            part = readSPIDERfile(string);   
            par(:,tot) = part(:);
        else
            break;
        end
    end
    if tot  == mmax
        break;
    end
end



